s=0
for i in str(2**1000):
    s+=int(i)
print s
