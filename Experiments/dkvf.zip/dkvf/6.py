suosq=100*201*101/6
sqosu=(100*101/2)**2
print suosq-sqosu
