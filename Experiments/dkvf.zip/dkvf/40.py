st="0."
for i in xrange(1,1000001):
    st=st+str(i)

print int(st[2])*int(st[11])*int(st[101])*int(st[1001])*int(st[10001])*int(st[100001])*int(st[1000001])
