s=0
n=10
def sa(x):
    m=0
    for i in str(x):
        m+=int(i)**5
    return m
while 1==1:
    if n==sa(n):
        s+=n
        print s
    n+=1
        
    
    
