for i in range(2,1000):
    print float(10000000000.0/float(i))
