import os
str = """Selena Gomez - Hands To Myself (Fareoh Remix)

SparkPulse - MOONAGE DAYDREAM (David Bowie)

Pegboard Nerds & NGHTMRE - Superstar (feat. Krewella)

Toby Green - Everytime (Out Now!)

Oliver Heldens & Shaun Frank - Shades Of Grey (Steve Void Remix)

Rich Edwards - Where I'll Be Waiting (feat. Cozi Zuehlsdorff)

Meg &amp; Dia - Monster (DotEXE Remix)

Link To The Future - James Landino - Hyrule Castle (Courage)

Conro - The Saint

PIXL - Sugar Rush

Miracle + X Ambassadors - Renegades

Varien - Sacred Woods (feat. Skyelle)

Bullet Train by Stephen Swartz ft. Joni Fatora

Nitro Fun & Hyper Potions - Checkpoint

Tommy Trash - Luv U Giv (NGHTMRE Remix)

Skrux - Infinite ft. Anna Yvette [EDM.com Exclusive]

W&W - How Many

Wafia - Heartburn (Felix Cartal Remix)

Korn 'Narcissistic Cannibal (feat Skrillex and Kill the Noise)'

Vicetone - Hawt Stuff

Muzzy - Junction Seven

Alan Walker - Faded (CH3VY Remix) [HypeThisMusic Exclusive]

Coldplay - Adventure Of A Lifetime (Audien Remix)

Rob Gasser & Raider - Ark

Alvita - Darkest Hour (Out Now)

Firebeatz & Chocolate Puma feat. Bish�p - Lullaby (OUT NOW)

Mr FijiWiji - Hostage (feat. Anna Yvette)

The Chainsmokers & Tritonal - Until You Were Gone (Justin Caruso Remix)

Dillon Francis & Kygo - Coming Over (Feat. James Hersey)

Pegboard Nerds - FrainBreeze

Inside Out

Galantis - No Money (Official Audio)

Infinite (Skrux feat. Anna Yvette) "Added Verses" (Doev Remix)

Madcon - Don't Worry ft Ray Dalton (Dj Torben Remix)

AREA21 - Spaceships

Star Wars: Episode VII Trailer Music - (Confidential Music & Ursine Vulpine - The Force Awakens)

Tomsize x Twenty One Pilots - Stressed Out

Avicii 'Levels' Skrillex Remix

OneRepublic - Counting Stars (Longarms Dubstep Remix)

DJ Isaac & Crystal Lake - Stick Em

Ape Drums - The Way We Do This (feat. Major Lazer & Busy Signal)

Kaskade & CID - Us

Doctor P and Flux Pavilion - Party Drink Smoke feat. Jarren Benton

Pegboard Nerds - Here It Comes

Snowbound

Pegboard Nerds - Self Destruct

Notaker - Infinite

Bring Back The Summer (Ft. Oly)

T-Mass - Last One Standing (feat. Openwater)

Elements by Lindsey Stirling

Infected Mushroom - I Wish (Ninja Kore Remix)

DJ DOGE - U LIFT ME UP ( Original Mix ) - Free Download

Razihel - Bad Boy [Monstercat Free Release]

Star Wars - Cantina Band (Noize Tank Remix) [Free Download]

Illenium & Dirt Monkey - Bring Forth The Pressure

Alessia Cara - Here

Twine - Dayjahvuh [Premiere])"""

lis=str.split('\n\n')
print lis

